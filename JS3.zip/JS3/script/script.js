// 
№1

let name = prompt("Ваше имя ?");
let age = prompt("Возраст");
let city = prompt("Город");
let phone = prompt("Телефон");
let email = prompt("Электронная почта");
let company = prompt("Место работы");
alert('Меня зовут   ' + name + '  ' + 'Мне   ' + age + '  ' +  'Я проживаю в    ' + city + '  ' + 'и работаю в   ' + company + '   ' + 'Мои контактные данные   ' + email  + '  ' + phone);
// №2 
alert(name + '  ' + 'родился в ' + ' ' + (2020 - age))

// №3
let str = '3216543';
if ((str[0]+str[1]+str[2]) == (str[3]+str[4]+str[5]))
	alert('Yes');
else{
	alert('No')
}
// №4
{let a = parseInt(prompt(('a ?')));
if (a > 0)
alert('Verno');
else{
	alert('Neverno');
}}
// №5
let a = 10;
let b = 2;
alert(a + b);
alert(a - b);
alert(a * b);
alert(a / b);
if ((a + b) > 1)
alert(Math.pow((a + b), 2))
// №6 
if ( a > 2 , a < 11 || b >= 6 , b < 14)
alert('verno');
else{
	alert('Neverno')
}
// №7
let n = parseInt(prompt('N?'));
if ( n < 1 ) n = 1;
if ( n > 59) n = 59;
if (n >= 1 && n <= 14) {
    alert ("Первая четверть");
 }
  if (n >= 15 && n <= 30) {
    alert ("Вторая четверть");
 }
 if (n >= 31 && n <= 45) {
    alert ("Третья четверть");
 }
 if (n >= 46 && n <= 59) {
    alert("Четвертая четверть");
}
// №8
let day  = parseInt(prompt('Day'));
if ( day < 1 ) day = 1;
if ( day > 31) day = 31;
if (day >= 1 && n <= 10) {
    alert ("Первая");
 }
  if (day >= 11 && day <= 20) {
    alert ("Вторая");
 }
 if (day >= 21 && day <= 31) {
    alert ("Третья");
 }
 // №9
 let days = parseInt(prompt('How many days ? M ?'));

 if (days < 365)
 	alert('< goda ');
 if (days < 30)
 	alert('< moth');
 if (days < 7)
 	alert('< week');
 alert(Math.floor(days / 365) + '  ' + ' Года' + '  ' + Math.floor(days / 30) + '   ' + ' Месяцев' + '  ' + Math.floor(days / 7) + '   ' + 'неделя' + '   ' + Math.floor(days * 24) + '   ' + 'часов' + '   ' + Math.floor(days * 1440) + '   '  + 'минут'  + '   ' + Math.floor(days * 86400) + '   ' + 'секунд');
// №10 

if (days > 365 ) days = 365;
if (days < 1 ) days = 1;
alert((Math.floor(days / 30) + '   ' + 'Месяц'));


var pora = Math.floor(days / 30) ;
if (pora < 1) pora = 1;
if ( pora > 12) pora = 12;

switch(pora){

 case 1:
 
 	alert('Зима')
 break;
  case 2:
 
 	alert('Зима')
 break;
  case 3:
 
 	alert('Зима')
 break;
 case 4:
 
 	alert('Весна')
 break;
  case 5:
 
 	alert('Весна')
 break;
  case 6:
 
 	alert('Весна')
 break;
 case 7:
 
 	alert('Лето')
 break;
 case 8:
 
 	alert('Лето')
 break;
 case 9:
 
 	alert('Лето')
 break;
 case 10:
 
 	alert('Осень')
 break;
  case 11:
 
 	alert('Осень')
 break;
  case 12:
 
 	alert('Осень')
 break;

}









