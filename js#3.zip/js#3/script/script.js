// #1

let a = [1,2,3,4,5];
for (i = 0; i < a.length; i++){
document.write(a[i] + '</br>' );	
}

// #2

var num = [-2, -1, -3, 15, 0, -4, 2, -5, 9, -15, 0, 4, 5, -6, 10, 7];
for (var i = 0; i < num.length; i++){
if (num[i] > -10 && num[i] < -3 )
console.log(num[i]);
}

// #3

let num2 = 0;
let result = 0;
for (var i = 23; i <= 57; i++){
	result = result + +[i];

}
console.log(result);

// №4

var num3 = ['10', '20', '30', '50', '235', '3000'];
for (var i = 0; i < num3.length; i++){
	if ( num3[i][0] == '1' || num3[i][0] == '2' || num3[i][0] == '5' ){
		console.log(num3[i]);
	}
}

// #5

var week = ['ПН' , 'ВТ' , 'СР' , 'ЧТ' , 'ПТ' , 'СБ' , 'ВС'];
for (var i = 0; i < week.length; i++){
	if ( i == 5 || i == 6){
		document.write('<b>' + week[i] + '</b>    ')
	}
	else{
		document.write(week[i] + '     ');
	}
}

// #6

var arrP = [1337 , 13123, 1313222, 223, 334];
arrP.push(669);
console.log(arrP + ',' + arrP[arrP.length - 1]);

// #7

let co = [];
	while (true){
		let vid = prompt('Enter valuev');
		if (vid != ''){
			co.push(+vid);
			co.sort(function(a,b){
				return a - b
			});

		}else{
			break;
		}
	}
	console.log(co);

// #8

let rev = [12, false, 'Текст', 4, 2, -5, 0];
console.log(rev.reverse())

// #9

let empty = [5, 9, 21, , , 9, 78, , , , , , , , , , 6];
        x = 0;

for(let i = 0; i < empty.length; i++) {
    if(empty[i] == undefined) x++; 
}
console.log(x);

// #10

let last = [48,9,0,4,21,12,1,0,8,84,76,8,4,13,2],
    z1 = last.indexOf(0),
    z2 = last.lastIndexOf(0),
    sum = 0;

if (z1 != -1 && z2 != -2) {
    for(let i = z1; i <= z2; i++) {
        sum = sum + last[i];
}
console.log(sum); }

// #11

var lines = line = prompt('Введите число от 1 до 8'),
         c=' ', 
         e='^';

while(line-->0){
 console.log(Array(line+1).join(c) + Array(2*(lines-line)).join(e) + Array(line+1).join(c));
}












